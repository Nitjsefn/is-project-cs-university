const Home = () => (
  <div className="text-center">
    <h1 className="text-4xl font-bold mb-4">System Integracji</h1>
    <p className="text-gray-600">Witaj w aplikacji do zarządzania danymi integracyjnymi.</p>
  </div>
)

export default Home
